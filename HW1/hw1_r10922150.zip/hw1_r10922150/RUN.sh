# DIP Homework Assignment #1
# Name: David Weng
# ID #: r10922150
# email: r10922150@ntu.edu.tw
python ./hw1.py