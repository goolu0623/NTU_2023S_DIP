# DIP Homework Assignment #3
# Name: David Weng
# ID #: r10922150
# email: r10922150@ntu.edu.tw
python ./hw3.py